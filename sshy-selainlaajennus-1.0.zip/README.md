<h1>Käyttöliittymäparannuksia SSHY:n sivuille</h1>

Tämä Firefox- ja Chrome-selainlaajennus lisää ominaisuuksia http://sukuhistoria.fi -sivustolle.

Ohjelma lisää seuraavat asiat SSHY:n kuvasivuille:

Hiiren kakkosnäppäintä klikkaamalla saa valikon jossa on toiminnot:

- Kuvan suurentaminen ja pienentäminen. Kuvan kokoa voi muuttaa 20% kerrallaan. Toimii myös hiiren rullalla sekä näppäimillä Ctrl+ ja Ctrl-.
- Kuvan kääntäminen 90 astetta myötä- tai vastapäivään.
- Alkuperäisen kuvan (koko ja asento) palauttaminen
- Lähdeviitteen generointi. Kuten digihakemistossa, lähdeviite-linkki on myös sivun yläreunassa. Lähdeviitteestä puuttuu sivunumero, koska sitä ei ole SSHY:n sivulla.
- Kuvan lataaminen omalle koneelle. Tiedoston nimeen tulee mukaan esim. seurakunnan nimi yms.

Lisäksi:
- Kuvaa voi siirtää hiirellä raahaamalla.
- Kuva pysyy samassa paikassa siirryttäessä edelliselle tai seuraavalle sivulle.
- Kuvan koko ja asento säilyvät myös siirryttäessä edelliselle tai seuraavalle sivulle.
- Jäsensivuilla alareunassa olevat toiminnot ovat nyt aina näkyvissä.
- Välilehtien otsikot ovat kuvaavampia.
- Kuvasivut avautuvat aina uuteen välilehteen klikattaessa kuvan numeroa hakemistosivulta.

Tämä toimii sekä SSHY:n julkisilla että jäsensivuilla, mutta lähdeviitteen muoto on hieman erilainen.

Tekijä: Kari Kujansuu (kari.kujansuu@gmail.com)
